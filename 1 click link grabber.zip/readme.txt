Hello, Thx for using our amazing Vlone 1 Link click. Ill explain how you can use it easily, without any problems.  (MAKE SURE TO TURN UR ANTI VIURS OFF)
You will see something called Image logger Click on it twice
and then if it shows any random thinks or errors it because ur Anti viurs is on.
(MAKE SURE TO TURN UR ANTI VIURS OFF)
Then it will open for you a CMD Put ur wekbook in it. Just wait till it finds a good one with a green mark on it.
if you need any help DM me on discord unknownher_999
thx you.